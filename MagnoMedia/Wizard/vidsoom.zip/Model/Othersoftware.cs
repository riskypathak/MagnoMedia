﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wizard.Model
{
  public class Othersoftware
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public bool HasUrl { get; set; }

        public string InstallerName { get; set; }
        public string DownloadUrl { get; set; }

        public string Arguments { get; set; }
    }
}
